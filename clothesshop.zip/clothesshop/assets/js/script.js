document.querySelector('#searchToggle').addEventListener("click", function(){
    document.querySelector('#searchBar').classList.toggle("d-none");
});

document.querySelectorAll(".toggleFilters").forEach(button => 
    button.addEventListener("click", () => {
        document.querySelector('.filters').classList.toggle("d-none");

    })
  )